using System.Globalization;

namespace Prova_17_04_Guilherme_Vitor
{
    public partial class Form1 : Form
    {
        int i = 0;
        int j = 0;
        public Form1()
        {
            InitializeComponent();
            maskedTextBoxPlaca.Mask = "AAA-0000";
            gerarGradeListViewCaminhaoOnibus();
        }

        private void radioButtonOnibus_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.onibus;
            labelAssentos_Eixos.Text = "Qtd Assentos";
        }

        private void radioButtonCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.caminhao;
            labelAssentos_Eixos.Text = "Qtd Eixos";
        }
        public void gerarGradeListViewCaminhaoOnibus()// Gera as grades do List View PF
        {
            listView1.Columns.Add("Placa", 100).TextAlign = HorizontalAlignment.Center;
            listView1.Columns.Add("Ano", 150).TextAlign = HorizontalAlignment.Center;
            listView1.Columns.Add("Assentos", 100).TextAlign = HorizontalAlignment.Center;
            listView1.Columns.Add("Eixos", 100).TextAlign = HorizontalAlignment.Center;
            listView1.Columns.Add("Diaria", 100).TextAlign = HorizontalAlignment.Center;
            listView1.View = View.Details;
        }
        public void Mensagem()
        {
            MessageBox.Show("Dados Cadastrados com sucesso!!", "Cadastrado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        public void Limpar()
        {
            maskedTextBoxPlaca.Text = "";
            textBoxAno.Text = "";
            textBoxAssentos_Eixos.Text = "";
        }

        private void buttonCadastrar_MouseClick(object sender, MouseEventArgs e)
        {
            bool validacao = validaInformacao();
            if (radioButtonOnibus.Checked && validacao == true)
            {
                Onibus o = new Onibus(maskedTextBoxPlaca.Text,
                    Convert.ToInt32(textBoxAno.Text),
                    Convert.ToInt32(textBoxAssentos_Eixos.Text));

                string[] veiculoOnibus = new string[5];

                veiculoOnibus[0] = o.Placa;
                veiculoOnibus[1] = Convert.ToString(o.Ano);
                veiculoOnibus[2] = Convert.ToString(o.Assentos);
                veiculoOnibus[3] = "";
                veiculoOnibus[4] = string.Format(CultureInfo.GetCultureInfo("pt-br"), "{0:C}", o.alugar());

                listView1.Items.Add(new ListViewItem(veiculoOnibus));

                //Dados cadastrados com sucesso
                Mensagem();
                Limpar();
            }
            else if (radioButtonCaminhao.Checked && validacao == true)
            {
                validaInformacao();
               Caminhao c = new Caminhao(maskedTextBoxPlaca.Text,
                    Convert.ToInt32(textBoxAno.Text),
                    Convert.ToInt32(textBoxAssentos_Eixos.Text));

                string[] veiculoOnibus = new string[5];

                veiculoOnibus[0] = c.Placa;
                veiculoOnibus[1] = Convert.ToString(c.Ano);
                veiculoOnibus[2] = "";
                veiculoOnibus[3] = Convert.ToString(c.Eixos);
                veiculoOnibus[4] = string.Format(CultureInfo.GetCultureInfo("pt-br"), "{0:C}", c.alugar());

                listView1.Items.Add(new ListViewItem(veiculoOnibus));

                //Dados cadastrados com sucesso
                Mensagem();
                Limpar();
            }

        }

         public void Mensagem (string labelM)
            {
                MessageBox.Show("Voc� deve informar a" + labelM +"  corretamente!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
    public bool validaInformacao()
        {
            bool validar = true;

            if(maskedTextBoxPlaca.MaskCompleted == false)
            {
                MessageBox.Show("Voc� deve informar a Placa corretamente!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                validar = false;
            }
            else if (textBoxAno.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Voc� deve informar o Ano corretamente!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                validar = false;
            }
            else if (textBoxAssentos_Eixos.Text.Trim() == string.Empty)
            {
                if (radioButtonCaminhao.Checked)
                {
                    Mensagem(labelAssentos_Eixos.Text);
                }
                else if(radioButtonOnibus.Checked){
                    Mensagem(labelAssentos_Eixos.Text);
                }
                validar = false;
            }
            return validar;
        }

        private void maskedTextBoxPlaca_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar)&& e.KeyChar !=44 && e.KeyChar !=8 && e.KeyChar != 202) {
                e.Handled = true;
            }
        }

        private void textBoxAno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8  && e.KeyChar != 202)
            {
                e.Handled = true;
            }
        }

        private void buttonLimpar_MouseClick(object sender, MouseEventArgs e)
        {
            Limpar();
        }

        private void textBoxAssentos_Eixos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 202)
            {
                e.Handled = true;
            }
        }
    }
}
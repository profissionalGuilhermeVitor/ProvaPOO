﻿namespace Prova_17_04_Guilherme_Vitor
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioButtonOnibus = new System.Windows.Forms.RadioButton();
            this.radioButtonCaminhao = new System.Windows.Forms.RadioButton();
            this.maskedTextBoxPlaca = new System.Windows.Forms.MaskedTextBox();
            this.labelPlaca = new System.Windows.Forms.Label();
            this.labelAno = new System.Windows.Forms.Label();
            this.labelAssentos_Eixos = new System.Windows.Forms.Label();
            this.buttonCadastrar = new System.Windows.Forms.Button();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBoxAno = new System.Windows.Forms.TextBox();
            this.textBoxAssentos_Eixos = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButtonOnibus
            // 
            this.radioButtonOnibus.AutoSize = true;
            this.radioButtonOnibus.Location = new System.Drawing.Point(21, 10);
            this.radioButtonOnibus.Name = "radioButtonOnibus";
            this.radioButtonOnibus.Size = new System.Drawing.Size(63, 19);
            this.radioButtonOnibus.TabIndex = 0;
            this.radioButtonOnibus.TabStop = true;
            this.radioButtonOnibus.Text = "Ônibus";
            this.radioButtonOnibus.UseVisualStyleBackColor = true;
            this.radioButtonOnibus.CheckedChanged += new System.EventHandler(this.radioButtonOnibus_CheckedChanged);
            // 
            // radioButtonCaminhao
            // 
            this.radioButtonCaminhao.AutoSize = true;
            this.radioButtonCaminhao.Location = new System.Drawing.Point(194, 10);
            this.radioButtonCaminhao.Name = "radioButtonCaminhao";
            this.radioButtonCaminhao.Size = new System.Drawing.Size(80, 19);
            this.radioButtonCaminhao.TabIndex = 1;
            this.radioButtonCaminhao.TabStop = true;
            this.radioButtonCaminhao.Text = "Caminhão";
            this.radioButtonCaminhao.UseVisualStyleBackColor = true;
            this.radioButtonCaminhao.CheckedChanged += new System.EventHandler(this.radioButtonCaminhao_CheckedChanged);
            // 
            // maskedTextBoxPlaca
            // 
            this.maskedTextBoxPlaca.Location = new System.Drawing.Point(143, 50);
            this.maskedTextBoxPlaca.Name = "maskedTextBoxPlaca";
            this.maskedTextBoxPlaca.Size = new System.Drawing.Size(131, 23);
            this.maskedTextBoxPlaca.TabIndex = 2;
            this.maskedTextBoxPlaca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.maskedTextBoxPlaca_KeyPress);
            // 
            // labelPlaca
            // 
            this.labelPlaca.AutoSize = true;
            this.labelPlaca.Location = new System.Drawing.Point(48, 53);
            this.labelPlaca.Name = "labelPlaca";
            this.labelPlaca.Size = new System.Drawing.Size(35, 15);
            this.labelPlaca.TabIndex = 3;
            this.labelPlaca.Text = "Placa";
            // 
            // labelAno
            // 
            this.labelAno.AutoSize = true;
            this.labelAno.Location = new System.Drawing.Point(48, 96);
            this.labelAno.Name = "labelAno";
            this.labelAno.Size = new System.Drawing.Size(29, 15);
            this.labelAno.TabIndex = 4;
            this.labelAno.Text = "Ano";
            // 
            // labelAssentos_Eixos
            // 
            this.labelAssentos_Eixos.AutoSize = true;
            this.labelAssentos_Eixos.Location = new System.Drawing.Point(48, 150);
            this.labelAssentos_Eixos.Name = "labelAssentos_Eixos";
            this.labelAssentos_Eixos.Size = new System.Drawing.Size(77, 15);
            this.labelAssentos_Eixos.TabIndex = 5;
            this.labelAssentos_Eixos.Text = "Qtd Assentos";
            // 
            // buttonCadastrar
            // 
            this.buttonCadastrar.Location = new System.Drawing.Point(208, 223);
            this.buttonCadastrar.Name = "buttonCadastrar";
            this.buttonCadastrar.Size = new System.Drawing.Size(85, 39);
            this.buttonCadastrar.TabIndex = 6;
            this.buttonCadastrar.Text = "Cadastrar";
            this.buttonCadastrar.UseVisualStyleBackColor = true;
            this.buttonCadastrar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.buttonCadastrar_MouseClick);
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(340, 223);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(107, 39);
            this.buttonLimpar.TabIndex = 7;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.MouseClick += new System.Windows.Forms.MouseEventHandler(this.buttonLimpar_MouseClick);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(48, 310);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(630, 133);
            this.listView1.TabIndex = 10;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Prova_17_04_Guilherme_Vitor.Properties.Resources.onibus;
            this.pictureBox1.Location = new System.Drawing.Point(428, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 179);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // textBoxAno
            // 
            this.textBoxAno.Location = new System.Drawing.Point(143, 96);
            this.textBoxAno.Name = "textBoxAno";
            this.textBoxAno.Size = new System.Drawing.Size(131, 23);
            this.textBoxAno.TabIndex = 12;
            this.textBoxAno.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAno_KeyPress);
            // 
            // textBoxAssentos_Eixos
            // 
            this.textBoxAssentos_Eixos.Location = new System.Drawing.Point(143, 150);
            this.textBoxAssentos_Eixos.Name = "textBoxAssentos_Eixos";
            this.textBoxAssentos_Eixos.Size = new System.Drawing.Size(131, 23);
            this.textBoxAssentos_Eixos.TabIndex = 13;
            this.textBoxAssentos_Eixos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAssentos_Eixos_KeyPress);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 465);
            this.Controls.Add(this.textBoxAssentos_Eixos);
            this.Controls.Add(this.textBoxAno);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.buttonCadastrar);
            this.Controls.Add(this.labelAssentos_Eixos);
            this.Controls.Add(this.labelAno);
            this.Controls.Add(this.labelPlaca);
            this.Controls.Add(this.maskedTextBoxPlaca);
            this.Controls.Add(this.radioButtonCaminhao);
            this.Controls.Add(this.radioButtonOnibus);
            this.Name = "Form1";
            this.Text = "Cadastro de Veículos";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RadioButton radioButtonOnibus;
        private RadioButton radioButtonCaminhao;
        private MaskedTextBox maskedTextBoxPlaca;
        private Label labelPlaca;
        private Label labelAno;
        private Label labelAssentos_Eixos;
        private Button buttonCadastrar;
        private Button buttonLimpar;
        private ListView listView1;
        private PictureBox pictureBox1;
        private TextBox textBoxAno;
        private TextBox textBoxAssentos_Eixos;
    }
}
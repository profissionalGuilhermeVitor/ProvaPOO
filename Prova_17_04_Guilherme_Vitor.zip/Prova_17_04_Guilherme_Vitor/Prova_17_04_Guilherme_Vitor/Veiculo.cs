﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova_17_04_Guilherme_Vitor
{
    internal class Veiculo
    {
        protected string placa;
        protected int ano;

        public string Placa { get => placa; set => placa = value; }
        public int Ano { get => ano; set => ano = value; }

        public Veiculo()
        {
            placa = string.Empty;
            ano = 0;
        }

        public Veiculo(string _placa,int _ano)
        {
            placa = _placa;
            ano = _ano;
        }

        public virtual double alugar()
        {
            return 0.0;
        }
    }
}
